Mobile Application:
1) Open the files in the health-care app folder using android studio
2) Build and run the code 
3) Install the built program in the android phone. If all the steps are completed, the application is successfully built.


Web application:
Bascially, just go to the url: http://healthmonitoringhomepage-env.5ndteffiz2.us-east-2.elasticbeanstalk.com/
Or, there's another way. 
Step 1: Git clone our repositories
Step 2: Open Terminal Commend
Step 3: cd to the path of our repositories you just cloned
Step 4: Use the commend line "cd HomePage"
Step 5: Use the commend line "php -S 127.0.0.1:8080"
Step 6: Open you broswer, and then type "127.0.0.1:8080" in your searching area. Then you will be able to view the website.






