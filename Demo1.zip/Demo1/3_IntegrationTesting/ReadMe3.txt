Mobile Application:
1) The integration for this part is communication between the application and the database on the remote server
2) This can be tested by trying to register the new user in the application .
3) After you have filled the details and clicked the register button. You will be routed to the login page. 
4) Now Try logging in
5) If the above steps are successully followed, then the system has been integrated successfully




Web Application:






